package com.shadow.agent;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;

public class LockAdminReceiver extends DeviceAdminReceiver {
    @Override
    public void onEnabled(Context c, Intent i) { super.onEnabled(c, i); }
    @Override
    public void onDisabled(Context c, Intent i) { super.onDisabled(c, i); }
}