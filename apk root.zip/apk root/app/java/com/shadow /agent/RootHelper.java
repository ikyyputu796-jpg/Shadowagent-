package com.shadow.agent;

import android.util.Log;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;

public class RootHelper {

    private static final String TAG = "SHADOW_ROOT";

    public static boolean isRooted() {
        try {
            Process p = Runtime.getRuntime().exec("su -c id");
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line = br.readLine();
            br.close();
            return line != null && line.contains("uid=0");
        } catch (Exception e) {
            return false;
        }
    }

    public static String runCommand(String command) {
        StringBuilder output = new StringBuilder();
        try {
            Process p = Runtime.getRuntime().exec("su");
            DataOutputStream os = new DataOutputStream(p.getOutputStream());
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));

            os.writeBytes(command + "\n");
            os.writeBytes("exit\n");
            os.flush();

            String line;
            while ((line = br.readLine()) != null) {
                output.append(line).append("\n");
            }
            os.close();
            br.close();
            p.waitFor();
        } catch (Exception e) {
            Log.e(TAG, "Root exec error: " + e.getMessage());
            return "ERROR: " + e.getMessage();
        }
        return output.toString().trim();
    }

    public static boolean hasBinary() {
        String[] paths = {"/system/xbin/su", "/system/bin/su", "/sbin/su", "/su/bin/su", "/system/sbin/su"};
        for (String p : paths) {
            try {
                if (new java.io.File(p).exists()) return true;
            } catch (Exception ignored) {}
        }
        return false;
    }
}